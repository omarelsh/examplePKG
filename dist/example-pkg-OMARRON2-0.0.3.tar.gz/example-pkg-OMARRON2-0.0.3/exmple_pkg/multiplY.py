def mutliplY(a,b):
    return(a*b)
